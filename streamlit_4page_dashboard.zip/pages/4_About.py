
import streamlit as st

st.title("ℹ️ About")

st.write("This is a sample 4-page Streamlit dashboard project.")
st.write("You can upload this project to GitHub and deploy using Streamlit Cloud.")
